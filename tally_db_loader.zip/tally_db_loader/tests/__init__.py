"""
Tests for Tally Database Loader.

Run tests with: pytest tally_db_loader/tests/
"""

